## Resource links in dataset 

Listed below are useful links in this dataset : 

* Link(https://www.waikatoregion.govt.nz/assets/PageFiles/6446/Data.xlsx)
* Link(https://www.waikatoregion.govt.nz/assets/PageFiles/6436/data.xlsx)
* Link(https://www.waikatoregion.govt.nz/assets/PageFiles/43540/Waikato%20peat%20subsidence%20data.xlsx)
